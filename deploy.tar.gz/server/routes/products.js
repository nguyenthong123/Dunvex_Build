import crypto from "crypto";
const PROJECT_ID = "dunvex-89461";
const FIRESTORE_BASE = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents`;
async function getAccessToken() {
  const json = process.env.FIREBASE_SERVICE_ACCOUNT;
  if (!json) throw new Error("Missing FIREBASE_SERVICE_ACCOUNT env");
  const sa = JSON.parse(json);
  const header = { alg: "RS256", typ: "JWT", kid: sa.private_key_id };
  const now = Math.floor(Date.now() / 1e3);
  const claim = {
    iss: sa.client_email,
    sub: sa.client_email,
    aud: "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600,
    scope: "https://www.googleapis.com/auth/datastore"
  };
  function b64(str) {
    return Buffer.from(str).toString("base64url");
  }
  function b64obj(obj) {
    return Buffer.from(JSON.stringify(obj)).toString("base64url");
  }
  function sign(pk, data2) {
    const signer = crypto.createSign("RSA-SHA256");
    signer.update(data2);
    signer.end();
    return signer.sign(pk, "base64url");
  }
  const partial = `${b64obj(header)}.${b64obj(claim)}`;
  const signature = sign(sa.private_key, partial);
  const jwt = `${partial}.${signature}`;
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`
  });
  const data = await res.json();
  if (data.error) throw new Error(`Auth error: ${data.error_description || data.error}`);
  return data.access_token;
}
async function verifyApiKey(ownerId, key) {
  const token = await getAccessToken();
  const res = await fetch(`${FIRESTORE_BASE}/api_keys/${ownerId}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (res.status === 404) return false;
  const doc = await res.json();
  const fields = doc.fields || {};
  return fields.enabled?.booleanValue === true && fields.key?.stringValue === key;
}
async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, x-api-key, x-owner-id");
  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }
  if (req.method !== "GET") {
    return res.status(405).json({ error: "Method not allowed. Use GET." });
  }
  const apiKey = req.headers["x-api-key"] || req.headers["X-Api-Key"];
  const ownerId = req.headers["x-owner-id"] || req.headers["X-Owner-Id"];
  if (!apiKey) return res.status(401).json({ error: "Missing x-api-key header" });
  if (!ownerId) return res.status(400).json({ error: "Missing x-owner-id header" });
  try {
    const valid = await verifyApiKey(ownerId, apiKey);
    if (!valid) return res.status(403).json({ error: "Invalid or disabled API key" });
    const token = await getAccessToken();
    const url = `${FIRESTORE_BASE}:runQuery`;
    const queryBody = {
      structuredQuery: {
        from: [{ collectionId: "products" }],
        where: {
          fieldFilter: {
            field: { fieldPath: "ownerId" },
            op: "EQUAL",
            value: { stringValue: ownerId }
          }
        },
        limit: 500
      }
    };
    const productsRes = await fetch(url, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(queryBody)
    });
    if (!productsRes.ok) {
      const errText = await productsRes.text();
      throw new Error(`Firestore runQuery failed: ${productsRes.status} ${errText}`);
    }
    const data = await productsRes.json();
    const docs = Array.isArray(data) ? data.filter((item) => item.document).map((item) => item.document) : [];
    const products = docs.map((doc) => {
      const nameParts = doc.name.split("/");
      const id = nameParts[nameParts.length - 1];
      const f = doc.fields || {};
      return {
        id,
        name: f.name?.stringValue || "",
        category: f.category?.stringValue || f.categories?.stringValue || "",
        priceSell: Number(f.priceSell?.doubleValue || f.priceSell?.integerValue || 0),
        priceImport: Number(f.priceImport?.doubleValue || f.priceImport?.integerValue || 0),
        unit: f.unit?.stringValue || "",
        weight: f.density?.stringValue || (f.density?.doubleValue !== void 0 ? String(f.density.doubleValue) : "") || (f.density?.integerValue !== void 0 ? String(f.density.integerValue) : "") || "",
        stock: Number(f.stock?.doubleValue || f.stock?.integerValue || 0),
        articleNo: f.articleNo?.stringValue || "",
        specification: f.specification?.stringValue || "",
        packaging: f.packaging?.stringValue || ""
      };
    });
    return res.status(200).json({
      success: true,
      total: products.length,
      products
    });
  } catch (error) {
    console.error("Products API error:", error);
    return res.status(500).json({ error: error.message || "Internal server error" });
  }
}
export {
  handler as default
};
